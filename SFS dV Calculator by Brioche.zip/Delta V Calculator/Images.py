import tkinter as tk
from tkinter import *
from tkinter import PhotoImage
import sys, os

#Code by from Max on StackOverflow
#def  (relative_path):
#    try:
#        base_path = sys._MEIPASS
#    except Exception:
#        base_path = os.path.abspath(".")#
#
#    return os.path.join(base_path, relative_path)
####################################################
iconpic = PhotoImage(file =  ('AppIcon.png'))
importbanner = PhotoImage(file= ('Banner.png'))

AS = PhotoImage(file= ('AddStage.png'))
ASP = PhotoImage(file= ('AddStagePressed.png'))
ASBW = PhotoImage(file= ('AddStageBW.png'))

NS = PhotoImage(file= ('NextStage.png'))
NSP = PhotoImage(file= ('NextStagePressed.png'))
NSBW = PhotoImage(file= ('NextStageBW.png'))

PS = PhotoImage(file= ('PreviousStage.png'))
PSP = PhotoImage(file= ('PreviousStagePressed.png'))
PSBW = PhotoImage(file= ('PreviousStageBW.png'))

Calc = PhotoImage(file= ('Calculate.png'))
CalcP = PhotoImage(file= ('CalculatePressed.png'))
CalcBW = PhotoImage(file= ('CalculateBW.png'))

BP = PhotoImage(file= ('ButtonPlus.png'))
BPP = PhotoImage(file= ('ButtonPlusPressed.png'))

BM = PhotoImage(file= ('ButtonMinus.png'))
BMP = PhotoImage(file= ('ButtonMinusPressed.png'))

engines = PhotoImage(file = ('Engines.png'))

